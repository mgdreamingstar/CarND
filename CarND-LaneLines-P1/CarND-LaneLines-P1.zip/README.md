# Introduction

These are my project files of **Finding Lane Lines on the Road**.

`P1.ipynb` contains my project code.

`test_image_output\` and `test_video_output\` contain my image and video output.

`writeup_GuoRuichen.md` is my writeup about this project.